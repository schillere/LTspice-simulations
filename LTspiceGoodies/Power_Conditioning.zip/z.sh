#!/bin/sh
cd /run/media/tarzan/Data/\!work/swcad/ltspice_group/Power_Conditioning/
rm -rf *.raw *.log *.fft
cd -

